#define _STLP_PLATFORM "Free BSD"

#define _STLP_USE_UNIX_IO
