/** Automatically generated file. DO NOT MODIFY */
package com.arcsoft.ais.arcvc;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}