package com.arcsoft.ais.arcvc.bean;

public class PeerIdOnlineStatus {
	public String peerId;
	public String onlineStatus;
	public String getPeerId() {
		return peerId;
	}
	public void setPeerId(String peerId) {
		this.peerId = peerId;
	}
	public String getOnlineStatus() {
		return onlineStatus;
	}
	public void setOnlineStatus(String onlineStatus) {
		this.onlineStatus = onlineStatus;
	}
	
}
